============
Utils
============

.. meta::
   :description: Utils in pyTelegramBotAPI
   :keywords: ptba, pytba, pyTelegramBotAPI, utils, guide


util file
-------------------

.. automodule:: telebot.util
   :members:
   :undoc-members:
   :show-inheritance: