============
Types of API
============



.. automodule:: telebot.types
   :members:
   :undoc-members:
   :show-inheritance:
